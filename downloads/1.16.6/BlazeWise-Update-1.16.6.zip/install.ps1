# BlazeWise installer (runs from BlazeWise-Setup.exe).
# Installs for this Windows user only (no admin needed) into
# %LOCALAPPDATA%\Programs\BlazeWise, adds Start menu and desktop shortcuts
# and an entry in Settings > Apps. Your jobs and photos are NOT stored here:
# they stay in your BlazeWise data folder and are never touched.
param(
  # Test mode (used when building): install into [Target] only, with no
  # shortcuts, no Settings > Apps entry, no messages and no launch.
  [string]$Target,
  [switch]$Test
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

# Messages always show on top of every other window (they used to hide
# behind the app, so the install looked stuck).
function Ask([string]$text, [string]$buttons = 'OK', [string]$icon = 'Information') {
  return [System.Windows.Forms.MessageBox]::Show($text, 'BlazeWise', $buttons, $icon,
    [System.Windows.Forms.MessageBoxDefaultButton]::Button1,
    [System.Windows.Forms.MessageBoxOptions]::DefaultDesktopOnly)
}
function Say([string]$text, [string]$icon = 'Information') {
  if ($Test) { Write-Output $text; return }
  Ask $text 'OK' $icon | Out-Null
}

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
# Never stand inside the program folder that is about to be replaced.
Set-Location -LiteralPath $here
[System.IO.Directory]::SetCurrentDirectory($here)
$version = (Get-Content (Join-Path $here 'version.txt') -Raw).Trim()
$target = if ($Target) { $Target } else { Join-Path $env:LOCALAPPDATA 'Programs\BlazeWise' }
$exe = Join-Path $target 'BlazeWise.exe'

# The app must be closed while it is replaced. When updating from inside
# BlazeWise it closes by itself, so give it a few seconds first.
function Running { Get-Process -Name BlazeWise -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $exe } }
for ($i = 0; $i -lt 10 -and (Running); $i++) { Start-Sleep -Milliseconds 500 }
# Any other BlazeWise window still open (another copy, or one left open for
# days) is closed the normal way, like pressing its X. Work is always saved
# as it is typed, so nothing is lost.
if (Running) {
  Running | ForEach-Object { $null = $_.CloseMainWindow() }
  for ($i = 0; $i -lt 30 -and (Running); $i++) { Start-Sleep -Milliseconds 500 }
}
while (Running) {
  $r = Ask "BlazeWise is still open. Please close it, then press OK to carry on installing." 'OKCancel'
  if ($r -ne 'OK') { exit 1 }
}

try {
  # Replace the program files (never the data folder).
  if (Test-Path $target) { Remove-Item -LiteralPath $target -Recurse -Force }
  New-Item -ItemType Directory -Force -Path $target | Out-Null
  Expand-Archive -LiteralPath (Join-Path $here 'payload.zip') -DestinationPath $target -Force
  Copy-Item (Join-Path $here 'uninstall.ps1') (Join-Path $target 'uninstall.ps1') -Force

  if ($Test) { Say "Installed $version (test) to $target"; exit 0 }

  # Shortcuts (Start menu and desktop).
  $shell = New-Object -ComObject WScript.Shell
  $places = @(
    [Environment]::GetFolderPath('Programs'),
    [Environment]::GetFolderPath('Desktop')
  )
  foreach ($p in $places) {
    $lnk = $shell.CreateShortcut((Join-Path $p 'BlazeWise.lnk'))
    $lnk.TargetPath = $exe
    $lnk.WorkingDirectory = $target
    $lnk.IconLocation = "$exe,0"
    $lnk.Description = 'BlazeWise fire risk assessments'
    $lnk.Save()
  }

  # Settings > Apps entry (this user only).
  $key = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\BlazeWise'
  New-Item -Path $key -Force | Out-Null
  $size = [int]((Get-ChildItem $target -Recurse | Measure-Object Length -Sum).Sum / 1KB)
  $uninstall = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$target\uninstall.ps1`""
  $values = @{
    DisplayName = 'BlazeWise'
    DisplayVersion = $version
    Publisher = 'BlazeWise'
    DisplayIcon = "$exe,0"
    InstallLocation = $target
    UninstallString = $uninstall
    QuietUninstallString = "$uninstall -Quiet"
    NoModify = 1
    NoRepair = 1
    EstimatedSize = $size
  }
  foreach ($k in $values.Keys) {
    $type = if ($values[$k] -is [int]) { 'DWord' } else { 'String' }
    New-ItemProperty -Path $key -Name $k -Value $values[$k] -PropertyType $type -Force | Out-Null
  }
} catch {
  Say ("BlazeWise couldn't be installed:`n`n" + $_.Exception.Message + "`n`nNothing in your data was changed.") 'Error'
  exit 1
}

Say "BlazeWise $version is installed. It will open now.`n`nYour jobs, photos and reports are kept as they were."
Start-Process -FilePath $exe -WorkingDirectory $target
