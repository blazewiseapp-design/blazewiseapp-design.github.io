# Removes the BlazeWise program (Settings > Apps > BlazeWise > Uninstall).
# Your data folder (jobs, photos, reports, backups) is NOT removed.
param([switch]$Quiet)
Add-Type -AssemblyName System.Windows.Forms

$target = Join-Path $env:LOCALAPPDATA 'Programs\BlazeWise'
$exe = Join-Path $target 'BlazeWise.exe'

if (-not $Quiet) {
  $r = [System.Windows.Forms.MessageBox]::Show(
    "Remove the BlazeWise program from this PC?`n`nYour jobs, photos, reports and backups are kept. Install BlazeWise again and they will all be there.",
    'BlazeWise', 'OKCancel', 'Question')
  if ($r -ne 'OK') { exit 0 }
}

Get-Process -Name BlazeWise -ErrorAction SilentlyContinue |
  Where-Object { $_.Path -eq $exe } | Stop-Process -Force

$shell = New-Object -ComObject WScript.Shell
foreach ($p in @([Environment]::GetFolderPath('Programs'), [Environment]::GetFolderPath('Desktop'))) {
  $lnk = Join-Path $p 'BlazeWise.lnk'
  if ((Test-Path $lnk) -and ($shell.CreateShortcut($lnk).TargetPath -eq $exe)) {
    Remove-Item -LiteralPath $lnk -Force
  }
}
Remove-Item -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\BlazeWise' -Recurse -Force -ErrorAction SilentlyContinue

# The program folder holds this script, so remove it after we finish.
Start-Process -FilePath cmd.exe -ArgumentList "/c timeout /t 2 >nul & rmdir /s /q `"$target`"" -WindowStyle Hidden

if (-not $Quiet) {
  [System.Windows.Forms.MessageBox]::Show('BlazeWise has been removed. Your data is still saved.', 'BlazeWise') | Out-Null
}
